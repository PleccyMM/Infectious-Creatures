﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using Verse;

namespace InfectiousCreatures
{
    public class CompUseEffect_HealMegaspiderParalysis : CompUseEffect
    {

        public override void DoEffect(Pawn usedBy)
        {
            base.DoEffect(usedBy);
            Hediff hediff = this.FindMegaSpiderParalysisHediff(usedBy);
            if (hediff != null)
            {
                this.Cure(hediff);
                return;
            }
            Hediff hediff2 = this.FindMegaSpiderParalysis(usedBy);
            if (hediff2 != null)
            {
                this.Cure(hediff2);
                return;
            }
        }


        private Hediff FindMegaSpiderParalysisHediff(Pawn pawn)
        {
            Hediff hediff = null;
            float num = -1f;
            List<Hediff> hediffs = pawn.health.hediffSet.hediffs;
            for (int i = 0; i < hediffs.Count; i++)
            {
                if (hediffs[i].Visible && hediffs[i].def.everCurableByItem)
                {
                    HediffStage curStage = hediffs[i].CurStage;
                    if (curStage != null && curStage.lifeThreatening)
                    {
                        float num2 = (hediffs[i].Part == null) ? 999f : hediffs[i].Part.coverageAbsWithChildren;
                        if (hediff == null || num2 > num)
                        {
                            hediff = hediffs[i];
                            num = num2;
                        }
                    }
                }
            }
            return hediff;
        }

        private Hediff FindMegaSpiderParalysis(Pawn pawn)
        {
            Hediff hediff = null;
            float num = -1f;
            List<Hediff> hediffs = pawn.health.hediffSet.hediffs;
            for (int i = 0; i < hediffs.Count; i++)
            {
                if (hediffs[i].def == HediffDefOf.MegaSpiderParalysis)
                {
                    float num2 = (hediffs[i].Part == null) ? 999f : hediffs[i].Part.coverageAbsWithChildren;
                    if (hediff == null || num2 > num)
                    {
                        hediff = hediffs[i];
                        num = num2;
                    }
                }
            }
            return hediff;
        }


        private void Cure(Hediff hediff)
        {
            Pawn pawn = hediff.pawn;
            pawn.health.RemoveHediff(hediff);
            if (hediff.def.cureAllAtOnceIfCuredByItem)
            {
                while (true)
                {
                    Hediff firstHediffOfDef = pawn.health.hediffSet.GetFirstHediffOfDef(hediff.def, false);
                    if (firstHediffOfDef == null)
                    {
                        break;
                    }
                    pawn.health.RemoveHediff(firstHediffOfDef);
                }
            }
            Messages.Message("MessageHediffCuredByItem".Translate(new object[]
            {
                hediff.LabelBase
            }), pawn, MessageTypeDefOf.PositiveEvent);
        }

        private bool CanKill(Hediff hediff)
        {
            if (hediff.def.stages != null)
            {
                for (int i = 0; i < hediff.def.stages.Count; i++)
                {
                    if (hediff.def.stages[i].lifeThreatening)
                    {
                        return true;
                    }
                }
            }
            return hediff.def.lethalSeverity >= 0f;
        }
    }
}
