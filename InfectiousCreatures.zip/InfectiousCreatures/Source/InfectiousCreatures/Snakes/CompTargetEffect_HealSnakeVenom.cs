﻿using RimWorld;
using System.Collections.Generic;
using Verse;
using Verse.AI;

namespace InfectiousCreatures
{
    public class CompTargetEffect_HealMegaspiderVenom : CompTargetEffect
    {

        public override void DoEffectOn(Pawn user, Thing target)
        {
            Pawn pawn = (Pawn)target;
            if (pawn.Dead)
            {
                return;
            }
            if (!user.CanReserveAndReach(target, PathEndMode.Touch, Danger.Deadly, 1, -1, null, false))
            {
                return;
            }
            Hediff hediff = this.FindSnakeVenomHediff(pawn);
            if (hediff != null)
            {
                this.Cure(hediff);
                return;
            }
            Hediff hediff2 = this.FindSnakeVenom(pawn);
            if (hediff2 != null)
            {
                this.Cure(hediff2);
                return;
            }
        }


        private Hediff FindSnakeVenomHediff(Pawn pawn)
        {
            Hediff hediff = null;
            float num = -1f;
            List<Hediff> hediffs = pawn.health.hediffSet.hediffs;
            for (int i = 0; i < hediffs.Count; i++)
            {
                if (hediffs[i].Visible && hediffs[i].def.everCurableByItem)
                {
                    HediffStage curStage = hediffs[i].CurStage;
                    if (curStage != null && curStage.lifeThreatening)
                    {
                        float num2 = (hediffs[i].Part == null) ? 999f : hediffs[i].Part.coverageAbsWithChildren;
                        if (hediff == null || num2 > num)
                        {
                            hediff = hediffs[i];
                            num = num2;
                        }
                    }
                }
            }
            return hediff;
        }

        private Hediff FindSnakeVenom(Pawn pawn)
        {
            Hediff hediff = null;
            float num = -1f;
            List<Hediff> hediffs = pawn.health.hediffSet.hediffs;
            for (int i = 0; i < hediffs.Count; i++)
            {
                if (hediffs[i].def == HediffDefOf.SnakeVenom)
                {
                    float num2 = (hediffs[i].Part == null) ? 999f : hediffs[i].Part.coverageAbsWithChildren;
                    if (hediff == null || num2 > num)
                    {
                        hediff = hediffs[i];
                        num = num2;
                    }
                }
            }
            return hediff;
        }


        private void Cure(Hediff hediff)
        {
            Pawn pawn = hediff.pawn;
            pawn.health.RemoveHediff(hediff);
            if (hediff.def.cureAllAtOnceIfCuredByItem)
            {
                while (true)
                {
                    Hediff firstHediffOfDef = pawn.health.hediffSet.GetFirstHediffOfDef(hediff.def, false);
                    if (firstHediffOfDef == null)
                    {
                        break;
                    }
                    pawn.health.RemoveHediff(firstHediffOfDef);
                }
            }
            
        }

        private bool CanKill(Hediff hediff)
        {
            if (hediff.def.stages != null)
            {
                for (int i = 0; i < hediff.def.stages.Count; i++)
                {
                    if (hediff.def.stages[i].lifeThreatening)
                    {
                        return true;
                    }
                }
            }
            return hediff.def.lethalSeverity >= 0f;
        }
    }
}
