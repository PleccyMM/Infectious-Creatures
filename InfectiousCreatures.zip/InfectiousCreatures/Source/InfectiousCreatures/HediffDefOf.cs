﻿using System;
using Verse;
using RimWorld;

namespace InfectiousCreatures
{
    [DefOf]
    public static class HediffDefOf
    {
        public static HediffDef SnakeVenom;

        public static HediffDef VenomPoisoning;

        public static HediffDef MegaSpiderVenom;

        public static HediffDef MegaSpiderParalysis;
    }
}